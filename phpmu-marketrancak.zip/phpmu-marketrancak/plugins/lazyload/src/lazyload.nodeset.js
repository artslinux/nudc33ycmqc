export const nodeSetToArray = nodeSet => Array.prototype.slice.call(nodeSet);
